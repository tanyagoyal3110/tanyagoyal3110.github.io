module.exports.Tweet = require('./tweet.model');

module.exports.tweetRoutes = require('./tweet.routes');

module.exports.tweetController = require('./tweet.controller');
