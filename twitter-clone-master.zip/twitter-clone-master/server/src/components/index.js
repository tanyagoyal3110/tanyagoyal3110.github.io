module.exports.users = require('./users');

module.exports.auth = require('./auth');

module.exports.profiles = require('./profiles');

module.exports.tweets = require('./tweets');
