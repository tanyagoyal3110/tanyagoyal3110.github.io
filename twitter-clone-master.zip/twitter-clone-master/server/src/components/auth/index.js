module.exports.authRoutes = require('./auth.routes');

module.exports.authController = require('./auth.controller');
