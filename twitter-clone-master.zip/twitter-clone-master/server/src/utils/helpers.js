const formatUsername = (username) => username.split(' ').join('').toLowerCase();

module.exports = {
  formatUsername,
};
